#include <mbed.h>
#include <EthernetInterface.h>
#include <USBSerial.h>
#include <rtos.h>
#include <mbed_events.h>
#include <C12832.h>

EthernetInterface eth;
UDPSocket udp;
unsigned char buffer[8];

char servAddr[] = "192.168.1.253";
SocketAddress server(servAddr, 5000);

union {
  double xx;
  unsigned char bts[8];
} u;

/*** Switch to big-endian! Reverse byte order in byte array
  * in: b; out: r
  **/
void revBytes(unsigned char *b, unsigned char *r, int lh) {
  int i=0;
  for (i = 0; i < lh; i++)
    r[lh-1-i] = b[i];
}

AnalogIn left(A0), right(A1);
C12832 lcd(D11, D13, D12, D7, D10); // Using Arduino pin notation

DigitalOut red(LED_RED,1); /* initial state 1 led is off */
DigitalOut green(LED_GREEN,1);
DigitalOut blue(LED_BLUE,1);
bool flashing = true;

/** update RGB LED: RGB = bottom 3 bits of s */
void flash(void) {
  static unsigned char s = 0; //initilised on first call only
  if (flashing) {
    s++;
  } else {
    s = 0;
  }
  red.write(1 - (s&1));
  green.write(1 - ((s>>1)&1));
  blue.write(1 - ((s>>2)&1));
  wait(0.5);
}

void toggleFlash(void) {
  flashing = !flashing;
}

/***** main *****/
int main() {
  printf("connecting \n");
  eth.connect();
  const char *ip = eth.get_ip_address();
  printf("IP address is: %s\n", ip ? ip : "No IP");

  udp.open(&eth);
  printf("sending to %s\n", servAddr);

  while (true) {
    u.xx = ((left.read() + right.read()*5)-3)*100;
    revBytes(u.bts, buffer, 8);
    nsapi_size_or_error_t r = udp.sendto(server, buffer, sizeof(buffer));
    if (r < 0)
      printf("sendto returned code %d\n",r);
    //  printf("sent %d: %f\n", r, u.xx);
    lcd.locate(0,10);
    lcd.printf("data = %f", u.xx);
    flash();
    wait(0.5);
  }
}
